package io.gblink.androidbridge;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.util.Base64;
import android.webkit.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int VID_CH340 = 0x1A86, PID_CH340 = 0x7523;
    static final int REQ_PERMISSION = 42;
    WebView web; UsbManager usb; UsbSerialCh340 serial; UsbDevice pending;
    Handler main = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        UsbSerialCh340.MainHolder.activity=this;
        usb=(UsbManager)getSystemService(USB_SERVICE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        TextView bar=new TextView(this); bar.setText("  GB-Link Android Bridge  •  CH340 / 921600");
        bar.setTextColor(Color.WHITE); bar.setBackgroundColor(Color.rgb(45,45,48)); bar.setTextSize(14); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setHeight(dp(42));
        root.addView(bar);
        web=new WebView(this); web.setBackgroundColor(Color.BLACK); root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new AndroidSerial(),"AndroidSerial");
        web.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String u){ inject(); } });
        web.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i,1001); fileCallback=cb; return true; }});
        web.loadUrl("https://switch.gblink.io/#switch");
        scanUsb();
    }
    ValueCallback<Uri[]> fileCallback;
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==1001&&fileCallback!=null){ fileCallback.onReceiveValue(c==RESULT_OK&&d!=null?new Uri[]{d.getData()}:null); fileCallback=null; } }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}

    void scanUsb(){ for(UsbDevice d:usb.getDeviceList().values()) if(d.getVendorId()==VID_CH340&&d.getProductId()==PID_CH340){ pending=d; if(usb.hasPermission(d)) openSerial(d); else requestPermission(d); } }
    void requestPermission(UsbDevice d){ pending=d; Intent i=new Intent("io.gblink.androidbridge.USB_PERMISSION"); i.setPackage(getPackageName()); PendingIntent pi=PendingIntent.getBroadcast(this,REQ_PERMISSION,i,PendingIntent.FLAG_IMMUTABLE); usb.requestPermission(d,pi); }
    void openSerial(UsbDevice d){ try { if(serial!=null)serial.close(); serial=new UsbSerialCh340(usb,d); serial.open(); inject(); } catch(Exception e){ toast("CH340: "+e.getMessage()); } }
    void toast(String s){ main.post(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show()); }
    @Override protected void onNewIntent(Intent i){ super.onNewIntent(i); UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE); if(d!=null) {pending=d; if(usb.hasPermission(d))openSerial(d); else requestPermission(d);} }
    final BroadcastReceiver rx=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){ if("io.gblink.androidbridge.USB_PERMISSION".equals(i.getAction())){ UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE); if(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false)&&d!=null)openSerial(d); else toast("USB permission denied"); } } };
    @Override protected void onResume(){super.onResume(); registerReceiver(rx,new IntentFilter("io.gblink.androidbridge.USB_PERMISSION"),Context.RECEIVER_NOT_EXPORTED); scanUsb();}
    @Override protected void onPause(){super.onPause(); try{unregisterReceiver(rx);}catch(Exception ignored){} }
    @Override protected void onDestroy(){if(serial!=null)serial.close(); web.destroy(); super.onDestroy();}

    void inject(){ if(web==null)return; web.evaluateJavascript(JS_POLYFILL,null); }
    class AndroidSerial {
        @JavascriptInterface public boolean available(){return serial!=null&&serial.isOpen();}
        @JavascriptInterface public void open(int baud){ try{ if(serial==null){scanUsb(); if(serial==null)throw new IOException("No CH340 found");} serial.setBaud(baud<=0?921600:baud); serial.startReader(); }catch(Exception e){toast("Serial open failed: "+e.getMessage());} }
        @JavascriptInterface public void write(String b64){ try{if(serial!=null)serial.write(Base64.decode(b64,Base64.NO_WRAP));}catch(Exception e){toast("Serial write failed: "+e.getMessage());} }
        @JavascriptInterface public void close(){if(serial!=null)serial.stopReader();}
        @JavascriptInterface public String info(){return serial==null?"none":"CH340 0x1A86:0x7523 @ "+serial.baud;}
    }
    void push(byte[] data){ String b=Base64.encodeToString(data,Base64.NO_WRAP); String js="window.__gblinkAndroidRx && window.__gblinkAndroidRx('"+b+"')"; main.post(()->web.evaluateJavascript(js,null)); }

    static final String JS_POLYFILL=""+
      "(()=>{if(window.__gblinkPoly)return;window.__gblinkPoly=1;"+
      "const A=window.AndroidSerial;"+
      "class R{constructor(){this.q=[];this.wait=[];this.closed=false;} push(x){if(this.wait.length)this.wait.shift()({value:x,done:false});else this.q.push(x);} cancel(){this.closed=true;this.q=[];this.wait=[];} getReader(){let s=this;return {read:()=>new Promise(r=>{if(s.q.length)r({value:s.q.shift(),done:false});else if(s.closed)r({value:undefined,done:true});else s.wait.push(r)}),releaseLock:()=>{}}}}"+
      "class W{constructor(){this.lock=false;}getWriter(){let a=this;return {write:x=>{let b=x instanceof Uint8Array?x:new Uint8Array(x);let s='';for(let i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);A.write(btoa(s));return Promise.resolve();},releaseLock:()=>{}}}}"+
      "class P{constructor(){this.readable=new R();this.writable=new W();this.opened=false;}open(o){A.open(o&&o.baudRate||921600);this.opened=true;return Promise.resolve();}close(){A.close();this.opened=false;this.readable.cancel();return Promise.resolve();}getInfo(){return {usbVendorId:0x1A86,usbProductId:0x7523};}}"+
      "window.__gblinkPorts=[new P()];window.__gblinkAndroidRx=(b)=>{let s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);window.__gblinkPorts[0].readable.push(u)};Object.defineProperty(navigator,'serial',{configurable:true,value:{getPorts:async()=>window.__gblinkPorts,requestPort:async()=>window.__gblinkPorts[0],addEventListener:()=>{},removeEventListener:()=>{}}});"+
      "})();";
}

package io.gblink.androidbridge;

import android.hardware.usb.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Minimal CH340/CH341 USB-host driver for the GB-Link ESP32 bridge.
 *  Based on the publicly documented CH34x vendor requests used by
 *  usb-serial-for-android; no third-party library is required. */
public final class UsbSerialCh340 {
    final UsbManager manager; final UsbDevice device; UsbDeviceConnection conn; UsbEndpoint in,out;
    Thread reader; final AtomicBoolean running=new AtomicBoolean(false); volatile int baud=921600;
    static final int TIMEOUT=1000;
    UsbSerialCh340(UsbManager m,UsbDevice d){manager=m;device=d;}
    boolean isOpen(){return conn!=null;}
    void open() throws IOException {
        conn=manager.openDevice(device); if(conn==null)throw new IOException("Android could not open CH340");
        for(int i=0;i<device.getInterfaceCount();i++) if(!conn.claimInterface(device.getInterface(i),true)) throw new IOException("Could not claim USB interface");
        UsbInterface it=device.getInterface(device.getInterfaceCount()-1);
        for(int i=0;i<it.getEndpointCount();i++){UsbEndpoint e=it.getEndpoint(i);if(e.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK){if(e.getDirection()==UsbConstants.USB_DIR_IN)in=e;else out=e;}}
        if(in==null||out==null)throw new IOException("CH340 bulk endpoints not found");
        controlIn(0x5f,0,0,new byte[2]); controlOut(0xa1,0,0); setBaud(9600); controlIn(0x95,0x2518,0,new byte[2]); controlOut(0x9a,0x2518,0x0050); controlIn(0x95,0x0706,0,new byte[2]); controlOut(0xa1,0x501f,0xd90a); setBaud(baud); controlOut(0x9a,0x2518,0x00c3); // 8N1, RX/TX
        setBaud(baud);
    }
    int controlOut(int req,int value,int index){return conn.controlTransfer(UsbConstants.USB_TYPE_VENDOR|UsbConstants.USB_DIR_OUT,req,value,index,null,0,TIMEOUT);}
    int controlIn(int req,int value,int index,byte[] buf){return conn.controlTransfer(UsbConstants.USB_TYPE_VENDOR|UsbConstants.USB_DIR_IN,req,value,index,buf,buf.length,TIMEOUT);}
    public synchronized void setBaud(int b)throws IOException{
        if(conn==null)return; long factor,divisor;
        if(b==921600){divisor=7;factor=0xf300;} else {long base=1532620800L; int divmax=3; factor=base/b; divisor=divmax; while(factor>0xfff0&&divisor>0){factor>>=3;divisor--;} if(factor>0xfff0)throw new IOException("Unsupported baud "+b); factor=0x10000-factor;}
        divisor|=0x80; int v1=(int)((factor&0xff00)|divisor),v2=(int)(factor&0xff);
        if(controlOut(0x9a,0x1312,v1)<0||controlOut(0x9a,0x0f2c,v2)<0)throw new IOException("CH340 baud setup failed"); baud=b;
    }
    void write(byte[] data)throws IOException{if(conn==null||out==null)throw new IOException("Serial not open");int off=0;while(off<data.length){int n=Math.min(16384,data.length-off);byte[] p=(off==0&&n==data.length)?data:Arrays.copyOfRange(data,off,off+n);int w=conn.bulkTransfer(out,p,0,p.length,TIMEOUT);if(w<=0)throw new IOException("USB write failed");off+=w;}}
    void startReader(){if(reader!=null&&reader.isAlive())return;running.set(true);reader=new Thread(()->{byte[] b=new byte[32768];while(running.get()&&conn!=null){int n=conn.bulkTransfer(in,b,0,b.length,50);if(n>0){byte[] x=Arrays.copyOf(b,n);MainHolder.push(this,x);}}},"gblink-ch340-reader");reader.start();}
    void stopReader(){running.set(false);}
    void close(){stopReader();try{if(conn!=null){for(int i=0;i<device.getInterfaceCount();i++)try{conn.releaseInterface(device.getInterface(i));}catch(Exception ignored){}conn.close();}}finally{conn=null;}}
    static class MainHolder{static MainActivity activity;static void push(UsbSerialCh340 s,byte[] d){if(activity!=null)activity.push(d);}}
}
